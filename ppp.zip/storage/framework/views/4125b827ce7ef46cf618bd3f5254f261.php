
<img src="<?php echo e(asset(config('app.logo_path'))); ?>" <?php echo e($attributes); ?> alt="logo">

<?php /**PATH D:\Xampp\htdocs\awc\awc-pos-main\resources\views/components/application-logo.blade.php ENDPATH**/ ?>