<form class="dropdown-item" method="POST" action="<?php echo e(route('logout')); ?>">
    <?php echo csrf_field(); ?>
    <a href="route('logout')" onclick="event.preventDefault();
                    this.closest('form').submit();">
        <?php echo e(__('Log Out')); ?>

    </a>
</form><?php /**PATH D:\Xampp\htdocs\awc\awc-pos-main\resources\views/components/logout.blade.php ENDPATH**/ ?>