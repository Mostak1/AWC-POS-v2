<div id="layoutSidenav_nav">
    <nav class="sb-sidenav accordion sb-sidenav text-primary-emphasis aw-bg sidebar text-success-emphasis " id="sidenavAccordion">
        <div class="sb-sidenav-menu">
            <div class="nav mt-2 side-nav">
                <?php
                    $user = Auth::guard('web')->user();
                ?>
                <!-- Navbar Brand-->
                <a class="navbar-brand ps-3 fs-1 text-warning" target="" href="<?php echo e(url('/')); ?>"><img width="150px"
                        src="<?php echo e(asset(config('app.logo_path'))); ?>" alt="Logo">
                </a>
                <div class="sb-sidenav-menu-heading clr">Core</div>
                <a class="nav-link" href="<?php echo e(url('/')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                    Dashboard
                </a>
                <div class="sb-sidenav-menu-heading clr">Interface</div>


                <?php if($user->can('category.index') || $user->can('subcategory.index') || $user->can('tab.index')): ?>
                    <a class="nav-link collapsed" href="#" data-bs-toggle="collapse"
                        data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                        <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                        Manage Tables
                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                    </a>
                    <div class="collapse" id="collapseLayouts" aria-labelledby="headingOne"
                        data-bs-parent="#sidenavAccordion">
                        <nav class="sb-sidenav-menu-nested  nav">
                            <?php if($user->can('category.index')): ?>
                                <a href="<?php echo e(url('category')); ?>" class="nav-link" rel="noopener noreferrer">
                                    <div class="sb-nav-link-icon"><i class="fa-brands fa-mendeley fa-beat-fade"></i>
                                    </div>
                                    Category
                                </a>
                            <?php endif; ?>
                            <?php if($user->can('subcategory.index')): ?>
                                <a href="<?php echo e(url('subcategory')); ?>" class="nav-link" rel="noopener noreferrer">
                                    <div class="sb-nav-link-icon"><i class="fa-brands fa-mendeley fa-beat-fade"></i>
                                    </div>
                                    Sub
                                    Category
                                </a>
                            <?php endif; ?>
                            <?php if($user->can('tab.index')): ?>
                                <a href="<?php echo e(url('tab')); ?>" class="nav-link" rel="noopener noreferrer">
                                    <div class="sb-nav-link-icon"><i class="fa-brands fa-mendeley fa-beat-fade"></i>
                                    </div>
                                    Table
                                    Set
                                </a>
                            <?php endif; ?>
                        </nav>
                    </div>
                <?php endif; ?>


                <?php if($user->can('menus.index')): ?>
                    <a class="nav-link" href="<?php echo e(url('menus')); ?>">
                        <div class="sb-nav-link-icon"><i class="fa-solid fa-utensils"></i></div>
                        Food Menu
                    </a>
                <?php endif; ?>
               
                <?php if($user->can('customer.index')): ?>
                    <a class="nav-link" href="<?php echo e(url('customer')); ?>">
                        <div class="sb-nav-link-icon"><i class="fa-solid fa-martini-glass-citrus"></i></div>
                        Customer Card
                    </a>
                <?php endif; ?>
                <?php if($user->can('order')): ?>
                    <a class="nav-link" href="<?php echo e(url('order')); ?>">
                        <div class="sb-nav-link-icon"><i class="fa-solid fa-martini-glass-citrus"></i></div>
                        Place Order
                    </a>
                <?php endif; ?>
                <?php if($user->can('supplier.index')): ?>
                    <a class="nav-link" href="<?php echo e(url('supplier')); ?>">
                        <div class="sb-nav-link-icon"><i class="fa-solid fa-truck-field"></i></div>
                        Supplier
                    </a>
                <?php endif; ?>
                <?php if($user->can('material.index')): ?>
                    <a class="nav-link" href="<?php echo e(url('material')); ?>">
                        <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                        Food Material
                    </a>
                <?php endif; ?>


                <?php if($user->can('purchase.index')): ?>
                    <a class="nav-link" href="<?php echo e(route('purchase.index')); ?>">
                        <div class="sb-nav-link-icon"><i class="fa-solid fa-store"></i></div>
                        Purchase Material
                    </a>
                <?php endif; ?>

                

                <div class="sb-sidenav-menu-heading clr">Report</div>
                
                <?php if($user->can('users.index')): ?>
                    <a class="nav-link" href="<?php echo e(url('users')); ?>">
                        <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                        Users
                    </a>
                <?php endif; ?>

                <?php if($user->can('roles.index')): ?>
                    <a class="nav-link" href="<?php echo e(url('admins')); ?>">
                        <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                        User Role Set
                    </a>
                <?php endif; ?>
               
                <?php if($user->can('roles.index')): ?>
                    <a class="nav-link" href="<?php echo e(url('roles')); ?>">
                        <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                        Permissions Set On Role
                    </a>
                <?php endif; ?>
                <?php if($user->can('permissions.index')): ?>
                    <a class="nav-link" href="<?php echo e(url('permissions')); ?>">
                        <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                        Permissions
                    </a>
                <?php endif; ?>
                <?php if($user->can('setting.index')): ?>
                    <a class="nav-link" href="<?php echo e(url('setting')); ?>">
                        <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                        Settings
                    </a>
                <?php endif; ?>


                
                <?php if(
                    $user->can('offorder.index') ||
                        $user->can('offorderlog') ||
                        $user->can('menulog') ||
                        $user->can('offorderdaily') ||
                        $user->can('offorderdetails.index') ||
                        $user->can('dailyreport')): ?>
                    <a class="nav-link collapsed" href="#" data-bs-toggle="collapse"
                        data-bs-target="#collapseLayouts1" aria-expanded="false" aria-controls="collapseLayouts1">
                        <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                        Report Manage
                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                    </a>
                    <div class="collapse" id="collapseLayouts1" aria-labelledby="headingOne"
                        data-bs-parent="#sidenavAccordion">
                        <nav class="sb-sidenav-menu-nested  nav">
                            <?php if($user->can('offorder.index')): ?>
                                <a href="<?php echo e(url('offorder')); ?>" class="nav-link" rel="noopener noreferrer">
                                    <div class="sb-nav-link-icon"><i class="fa-regular fa-flag"></i></div>
                                    Order
                                    History Report
                                </a>
                            <?php endif; ?>
                            <?php if($user->can('offorderlog')): ?>
                                <a href="<?php echo e(url('offorderlog')); ?>" class="nav-link" rel="noopener noreferrer">
                                    <div class="sb-nav-link-icon"><i class="fa-regular fa-flag"></i></div>
                                    Order Log
                                    History Report
                                </a>
                            <?php endif; ?>
                            <?php if($user->can('menulog')): ?>
                                <a href="<?php echo e(url('menulog')); ?>" class="nav-link" rel="noopener noreferrer">
                                    <div class="sb-nav-link-icon"><i class="fa-regular fa-flag"></i></div>
                                    Menu Log
                                    History Report
                                </a>
                            <?php endif; ?>
                            <?php if($user->can('offorderdaily')): ?>
                                <a href="<?php echo e(url('offorderdaily')); ?>" class="nav-link" rel="noopener noreferrer">
                                    <div class="sb-nav-link-icon"><i class="fa-regular fa-flag"></i></div>
                                    Daily Sale Report of Order
                                </a>
                            <?php endif; ?>
                            <?php if($user->can('offorderdetails.index')): ?>
                                <a href="<?php echo e(url('offorderdetails')); ?>" class="nav-link" rel="noopener noreferrer">
                                    <div class="sb-nav-link-icon"><i class="fa-regular fa-flag"></i></div>
                                    Order
                                    Details Table
                                </a>
                            <?php endif; ?>
                            <?php if($user->can('dailyreport')): ?>
                                <a href="<?php echo e(url('dailyreport')); ?>" class="nav-link" rel="noopener noreferrer">
                                    <div class="sb-nav-link-icon"><i class="fa-regular fa-flag"></i></div>
                                    Daily Sale Report Order Details
                                </a>
                            <?php endif; ?>
                        </nav>
                    </div>
                <?php endif; ?>
                
            </div>
        </div>
        <div class="sb-sidenav-footer clr">
            <div class="small">Logged in as:</div>

            <?php if(Auth::check()): ?>
                <?php echo e(Auth::user()->name); ?>

            <?php endif; ?>
        </div>
        <div class=" clr">Copyright &copy; <a href="https://mostaksarker.com/" class="nav-link" target="_blank" rel="noopener noreferrer"> Green Kitchen 2023</a></div>
    </nav>
</div>
<?php /**PATH D:\Xampp\htdocs\awc\awc-pos-main\resources\views/layouts/side_nav.blade.php ENDPATH**/ ?>