<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php if($message = Session::get('success')): ?>
    <script>
        Swal.fire({
            icon: 'success',
            title: 'Success!',
            text: '<?php echo e($message); ?>',
        });
    </script>
<?php endif; ?>


<?php if($message = Session::get('error')): ?>
<script>
    Swal.fire({
        icon: 'error',
        title: 'Opps! !',
        text: '<?php echo e($message); ?>',
    });
</script>
    
<?php endif; ?>
<?php if($message = Session::get('warning')): ?>
<script>
    Swal.fire({
        icon: 'warning',
        title: 'Warning!',
        text: '<?php echo e($message); ?>',
    });
</script>
    
<?php endif; ?>
<?php if($message = Session::get('info')): ?>
<script>
    Swal.fire({
        icon: 'warning',
        title: 'Please Wait!',
        text: '<?php echo e($message); ?>',
    });
</script>
    
<?php endif; ?>

<?php if($errors->any()): ?>
    <script>
        Swal.fire({
            title: 'Oops!',
            text: 'There were some errors with your form.',
            html: '<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <div class="alert alert-danger"><?php echo e($error); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>',
        });
    </script>
<?php endif; ?>
<?php if(Session::get('success', false)): ?>
    <?php $data = Session::get('success'); ?>
    <?php if(is_array($data)): ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-success" role="alert">
                <i class="fa fa-check"></i>
                <?php echo e($msg); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div class="alert alert-success" role="alert">
            <i class="fa fa-check"></i>
            <?php echo e($data); ?>

        </div>
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH D:\Xampp\htdocs\awc\awc-pos-main\resources\views/layouts/flash.blade.php ENDPATH**/ ?>