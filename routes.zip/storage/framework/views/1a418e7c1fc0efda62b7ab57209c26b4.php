
<?php $__env->startSection('css'); ?>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Oswald:wght@700&display=swap');

        @media print {

            table,
            .ptext,
            .r-text {
                font-size: 8pt;
                margin-bottom: 1px;
                font-weight: 900;
                font-family: "Oswald", sans-serif;
                font-optical-sizing: auto;
                font-style: normal;
            }

            th,
            td {
                padding: 0px;
                height: 4px;

            }

            @page {
                margin: 0.2in;
            }
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
        <h4 class="m-0 font-weight-bold text-info">Order Report Table</h4>
        <div class="m-0 font-weight-bold btn btn-outline-info" id="submitp"><i class="fa-solid fa-print"></i></div>

    </div>

    <div id="print" class="card p-2">
        <div class=" d-print-block">
            <div class="fs-4 text-center r-heading">GREEN KITCHEN</div>
            <div class="r-text  text-center">Islam Tower,2nd Floor,102 Shukrabad,Dhanmondi-32,Dhaka-1207 <br>
                Phone#
                01979756069
            </div>

            <div class="d-flex justify-content-between my-2">
                <div class="r-text ">
                    Date: <?php
                        $currentDateTime = date('Y-m-d');
                        echo $currentDateTime;
                    ?>

                </div>

                <div class="r-text ">
                    Time: <?php
                        $currentTime = date('h:i A');
                        echo $currentTime;
                    ?>

                </div>


            </div>
            <div class="d-flex justify-content-between my-2">
                <div class="fs-4 font-weight-bold">Paid</div>
                <div class="r-text">Invoice ID: 000<?php echo e($invoice); ?>

                </div>
            </div>
        </div>
        <div class="row row-cols-1 r-text  d-print-block">
            <div class="col">Payment Methode: <?php echo e($payMethod); ?></div>
            <div class="col"> <span id="transactionId1"></span></div>
        </div>


        <div id="invoiceStaff" class="text-center text-danger fs-4 my-2">

        </div>


        <div class="row r-text mb-2">
            <div class="col-3">
                Item
            </div>
            <div class="col-2">
                Qty
            </div>
            <div class="col-3">
                Price
            </div>
            <div class="col-2">
                Total
            </div>
        </div>


        <div class="orders r-text" id="orders">
            <?php if($active == 1): ?>
                <?php $__currentLoopData = $staffData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row r-text mb-2">
                        <div class="col-3">
                            <?php echo e($item['menuName']); ?>

                        </div>
                        <div class="col-2">
                            <?php echo e($item['quantity']); ?>

                        </div>
                        <div class="col-3">

                            <div class="">
                                <?php echo e($item['price']); ?>Tk
                            </div>
                        </div>
                        <div class="col-2">
                            <?php echo e($item['total']); ?>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <?php $__currentLoopData = $staffData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row r-text mb-2">
                        <div class="col-3">
                            <?php echo e($item['menuName']); ?>

                        </div>
                        <div class="col-2">
                            <?php echo e($item['quantity']); ?>

                        </div>
                        <div class="col-3">

                            <div class="text-decoration-line-through">
                                <?php echo e($item['price']); ?>Tk
                            </div>
                            <?php if($item['cprice'] !== 0): ?>
                                <?php echo e($item['cprice']); ?>Tk
                            <?php else: ?>
                                <?php echo e($item['sprice']); ?>Tk
                            <?php endif; ?>

                        </div>
                        <div class="col-2">
                            <?php echo e($item['total']); ?>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>



        


        
        <div class="r-text">
            <span>GROSS Total: <?php echo e($total); ?> </span>
            <span id="total-order2"></span>
            <span>TK</span>
        </div>
        <div class="r-text">
            <?php if($total > $total - $discount): ?>
                <div class="div">20% Discount Applied</div>
            <?php endif; ?>
            <span>Ammount to Pay: <?php echo e($total - $discount); ?> </span>
            <span id="total-order2"></span>
            <span>TK</span>
        </div>

        <div class="aw-ul r-text text-center">----------------</div>
        <div class="r-text d-print-block text-center">
            THANK YOU, COME AGAIN <br> Print By:
            <?php if(Auth::Check()): ?>
                <?php echo e(Auth::user()->name); ?>

            <?php endif; ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $('#submitp').click(function() {
            var printContents = $('#print').html();
            $(".order-q").removeClass("");
            var originalContents = document.body.innerHTML;
            document.body.innerHTML = printContents;
            window.print();
            document.body.innerHTML = originalContents;
            location.reload();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\awc\awc-pos-main\resources\views/receipt.blade.php ENDPATH**/ ?>