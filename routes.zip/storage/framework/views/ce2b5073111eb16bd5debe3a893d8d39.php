<?php $__env->startSection('content'); ?>
    <div class="card card-hover shadow mb-4">
        <!-- Card Header - Dropdown -->
        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
            <h4 class="m-0 font-weight-bold text-info">List of Classes</h4>
            <div class="">
                <a class="btn btn-sm btn-info" href="<?php echo e(url('category/create')); ?>">
                    <i class="fa-solid fa-plus"></i>
                    Add
                </a>
            </div>
        </div>
        <!-- Card Body -->
        <div class="card-body mt-4">
            <div class="table-responsive">
                <table class="table table-bordered" width="100%" cellspacing="0">
                    <thead>
                       
                        <tr>
                          
                            <th>Name</th>
                            <th>Address</th>
                            <th>Logo</th>
                            <th>Mobile</th>
                            <th>Phone</th>
                            <th>Website</th>
                            <th>Tax</th>
                            <th>Discount</th>
                            <th>Edit</th>
                        </tr>
                    </thead>
                    
                    <tbody>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                               
                                <td><?php echo e($item->c_name); ?></td>
                                <td><?php echo e($item->address); ?></td>
                                <td> <img class="" height="50px" src="<?php echo e(asset(config('app.logo_path'))); ?>" alt="logo" /></td>
                                <td><?php echo e($item->mobile); ?></td>
                                <td><?php echo e($item->phone); ?></td>
                                <td><?php echo e($item->website); ?></td>
                                <td><?php echo e($item->tax); ?></td>
                                <td><?php echo e($item->discount); ?></td>
                                
                                <td class="">
                                  
                                    &nbsp;
                                    <a href="<?php echo e(url('setting/' . $item->id . '/edit')); ?>" class="btn btn-info  btn-sm"
                                        title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    &nbsp;
                                   
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\awc\awc-pos-main\resources\views/setting/index.blade.php ENDPATH**/ ?>