<?php $__env->startSection('content'); ?>
    <div class="bg-white p-4 rounded-4 shadow-lg mb-5 bg-body-tertiary">
        <h1>Users</h1>
        <div class="lead">
            Manage users here.
        </div>
        
        <div class="mt-2">
            
        </div>

        <table class="table table-striped" id="dataTable">
            <thead>
            <tr>
                <th scope="col" width="1%">#</th>
                <th scope="col" width="15%">Name</th>
                <th scope="col">Email</th>
                <th scope="col" width="10%">Username</th>
              
                <th scope="col" width="1%" >Action</th>    
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($user->id); ?></th>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->username); ?></td>
                       
                        <td>
                            <div class="skip d-flex justify-content-center">
                                
                                <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-info btn-sm">Edit</a>
                            </div>
                        </td>
                        
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div class="d-flex">
         
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\awc\awc-pos-main\resources\views/users/index.blade.php ENDPATH**/ ?>