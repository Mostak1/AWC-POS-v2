<?php $__env->startSection('title'); ?>
    Admins - Admin Panel
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- page title area start -->
    <div class="page-title-area">
        <div class="row align-items-center">
            <div class="col-sm-6">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        
                        <li class="breadcrumb-item nav-link"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page">All Admins</li>
                    </ol>
                </nav>

            </div>
            <div class="col-sm-6 clearfix">
            </div>
        </div>
    </div>
    <!-- page title area end -->

    <div class="main-content-inner">
        <div class="row">
            <!-- data table start -->
            <div class="col-12 mt-5">
                <div class="bg-white rounded-4 p-4 shadow-lg">
                    <div class="card-body">
                        <h4 class="header-title float-start">Admins List</h4>
                        <p class="float-end mb-2">
                            <?php if(Auth::guard('web')->user()->can('admins.edit')): ?>
                                <a class="btn btn-primary" href="<?php echo e(route('admins.create')); ?>">Create New Admin</a>
                            <?php endif; ?>
                        </p>
                        <div class="clearfix"></div>
                        <div class="data-tables">
                            <table id="dataTable" class="table text-center">
                                <thead class="bg-light text-capitalize">
                                    <tr>
                                        <th width="5%">Sl</th>
                                        <th width="10%">Name</th>
                                        <th width="10%">Email</th>
                                        <th width="40%">Roles</th>
                                        <th width="15%">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->index + 1); ?></td>
                                            <td><?php echo e($admin->name); ?></td>
                                            <td><?php echo e($admin->email); ?></td>
                                            <td>
                                                <?php $__currentLoopData = $admin->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span class="badge bg-primary me-1">
                                                        <?php echo e($role->name); ?>

                                                    </span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                            <td>
                                                <a class="btn btn-success"
                                                    href="<?php echo e(route('admins.edit', $admin->id)); ?>">Edit</a>
                                                <?php if(Auth::guard('web')->user()->can('admins.edit')): ?>
                                                <?php endif; ?>

                                                <?php if(Auth::guard('web')->user()->can('admins.destroy')): ?>
                                                    <a class="btn btn-danger"
                                                        href="<?php echo e(route('admins.destroy', $admin->id)); ?>"
                                                        onclick="event.preventDefault(); document.getElementById('delete-form-<?php echo e($admin->id); ?>').submit();">
                                                        Delete
                                                    </a>
                                                    <form id="delete-form-<?php echo e($admin->id); ?>"
                                                        action="<?php echo e(route('admins.destroy', $admin->id)); ?>" method="POST"
                                                        style="display: none;">
                                                        <?php echo method_field('DELETE'); ?>
                                                        <?php echo csrf_field(); ?>
                                                    </form>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- data table end -->

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\awc\awc-pos-main\resources\views/admins/index.blade.php ENDPATH**/ ?>