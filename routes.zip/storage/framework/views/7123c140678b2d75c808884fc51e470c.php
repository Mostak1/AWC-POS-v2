<?php $__env->startSection('content'); ?>
    <div class="card card-hover shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between">
            <h4 class="m-0 font-weight-bold text-info">Update Customer Info</h4>
            <a href="<?php echo e(url('customer')); ?>" class="btn btn-info  btn-sm" title="Back to Customer">
                <i class="fas fa-arrow-left"></i>
            </a>
        </div>
        <div class="card-body">

            <?php echo Form::model($customer, [
                'method' => 'put',
                'enctype' => 'multipart/form-data',
                'class' => 'user',
                'route' => ['customer.update', ['customer' => $customer->id]],
            ]); ?>


            <div class="form-group row g-4">
                
                <div class="col-sm-4 mb-3 mb-sm-0">
                    <label for="mobile" class="form-label">Mobile :</label>
                    <?php echo Form::text('mobile', null, [
                        'required',
                        'class' => 'form-control form-control-profile',
                        'id' => 'mobile',
                        'placeholder' => 'Mobile Number',
                    ]); ?>

                </div>
                <div class="col-sm-4 mb-3 mb-sm-0">
                    <label for="address" class="form-label">Address :</label>
                    <?php echo Form::text('address', null, [
                        'required',
                        'class' => 'form-control form-control-profile',
                        'id' => 'address',
                        'placeholder' => 'Address',
                    ]); ?>

                </div>
                <div class="col-sm-4 mb-3 mb-sm-0">
                    <label for="discount_id" class="control-label">Discount Policy :</label>
                    <?php echo Form::select('discount_id', $discount, null, [
                        'required',
                        'class' => 'form-control',
                        'id' => 'discount_id',
                        'placeholder' => 'Discount Policy',
                    ]); ?>

                </div>
                
                <div class="col-sm-4 mb-3 mb-sm-0">
                    <label for="card_status" class="control-label">Sector:</label>
                    <?php echo Form::select(
                        'card_status',
                        [
                            1 => 'Customer',
                            2 => 'Staff',
                            3 => 'Pathao',
                            4 => 'Food Panda',
                            5 => 'Chairman Sir',
                            6 => 'IPD',
                        ],
                        null,
                        [
                            'class' => 'form-control',
                            'id' => 'card_status',
                        ],
                    ); ?>

                </div>
                
            </div>

        </div>
        <div class="form-group p-4">
            <?php echo Form::submit('Update Customer Info', ['class' => 'mt-3 btn btn-info btn-profile btn-block']); ?>

        </div>
        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\awc\awc-pos-main\resources\views/customer/edit.blade.php ENDPATH**/ ?>