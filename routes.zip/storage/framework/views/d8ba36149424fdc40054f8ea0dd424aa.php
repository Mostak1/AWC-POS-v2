<?php $__env->startSection('content'); ?>
    <div class="card card-hover shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between">
            <h4 class="m-0 font-weight-bold text-info"> Add Class</h4>
            <a href="<?php echo e(url('category')); ?>" class="btn btn-info  btn-sm" title="Back to Class List">
                <i class="fas fa-arrow-left"></i>
            </a>
        </div>
        <div class="card-body mt-1">
            <?php echo e(Form::open(['route' => 'category.store', 'class' => 'user', 'enctype' => 'multipart/form-data'])); ?>


            

            <div class="form-group row">
                <div class="col-sm-4 mb-3 mb-sm-0">
                    <label for="name" class="form-label">Name :</label>
                    <?php echo Form::text('name', null, [
                        'required',
                        'class' => 'form-control form-control-profile',
                        'id' => 'name',
                        'placeholder' => 'Name',
                    ]); ?>

                </div>
               
                <div class="col-sm-4">
                    <label for="image" class="form-label">Input Image:</label>
                        <?php echo Form::file('image', ['class' => 'form-control', 'id' => 'image', 'title' => 'Category Picture']); ?>

                    
                </div>
            </div>

           

            <div class="form-group">
                <?php echo Form::submit('Add Category', ['class' => 'my-3 btn btn-info']); ?>

            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\awc\awc-pos-main\resources\views/category/create.blade.php ENDPATH**/ ?>