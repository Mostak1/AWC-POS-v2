<?php $__env->startSection('content'); ?>
    <div class="card card-hover shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between">
            <h4 class="m-0 font-weight-bold text-info">Add Subject</h4>
            <a href="<?php echo e(url('supplier')); ?>" class="btn btn-info  btn-sm" title="Back to Subject List">
                <i class="fas fa-arrow-left"></i>
            </a>
        </div>
        <div class="card-body">
            <?php echo e(Form::open(['route' => 'supplier.store', 'class' => 'user', 'enctype' => 'multipart/form-data'])); ?>

            


            <div class="form-group row">
              
                <div class="col-sm-3 mb-2">
                    <?php echo Form::text('name', null, [
                        'required',
                        'class' => 'form-control form-control-profile',
                        'id' => 'name',
                        'placeholder' => 'Name',
                    ]); ?>

                </div>
                <div class="col-sm-3 mb-2">
                    <?php echo Form::email('email', null, [
                        'required',
                        'class' => 'form-control form-control-profile',
                        'id' => 'email',
                        'placeholder' => 'Email Address',
                    ]); ?>

                </div>
                <div class="col-sm-3 mb-2">
                    <?php echo Form::text('mobile', null, [
                        'required',
                        'class' => 'form-control form-control-profile',
                        'id' => 'mobile',
                        'placeholder' => 'Mobile Number',
                    ]); ?>

                </div>
                <div class="col-sm-3 mb-2">
                    <?php echo Form::text('address', null, [
                        'required',
                        'class' => 'form-control form-control-profile',
                        'id' => 'address',
                        'placeholder' => 'Address',
                    ]); ?>

                </div>
                <div class="col-sm-3 mb-2" >
                    <?php echo Form::text('web', null, [
                        'required',
                        'class' => 'form-control form-control-profile',
                        'id' => 'web',
                        'placeholder' => 'Web Address',
                    ]); ?>

                </div>
            </div>



            <div class="form-group">
                <?php echo Form::submit('Add Supplier', ['class' => 'btn btn-info btn-profile btn-block']); ?>

            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\awc\awc-pos-main\resources\views/supplier/create.blade.php ENDPATH**/ ?>