<?php $__env->startSection('content'); ?>
    <div class="card card-hover shadow mb-4">
        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
            <h4 class="m-0 font-weight-bold text-info">Supplier List</h4>
            <div class="">
                <a class="btn btn-sm btn-info" href="<?php echo e(url('supplier/create')); ?>">
                    <i class="fa-solid fa-plus"></i>
                    Add
                </a>
            </div>
        </div>
    </div>
    <!-- Card Body -->
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th colspan="7" class="tablebtn text-end">
                        </th>
                    </tr>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Mobile</th>
                        <th>Address</th>
                        <th>Website</th>
                        <th>Action</th>
                    </tr>
                </thead>
               
                <tbody>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($subcat->id); ?></td>
                            
                            <td><?php echo e($subcat->name); ?></td>
                            <td><?php echo e($subcat->email); ?></td>
                            <td><?php echo e($subcat->mobile); ?></td>
                            <td><?php echo e($subcat->address); ?></td>
                            <td><?php echo e($subcat->web); ?></td>
                            
                            <td class="skip d-flex justify-content-center">
                                
                                <?php echo Form::open(['method' => 'delete', 'route' => ['supplier.destroy', $subcat->id], 'id' => 'deleteform']); ?>

                                <a href="javascript:void(0)" class="btn btn-danger  btn-sm" title="Delete"
                                    onclick="event.preventDefault();if (!confirm('Are you sure?')) return; document.getElementById('deleteform').submit();">
                                    <i class="fa-solid fa-trash-can"></i>
                                </a>
                                <?php echo Form::close(); ?>

                                &nbsp;
                                <a href="<?php echo e(url('supplier/' . $subcat->id . '/edit')); ?>"
                                    class="btn btn-info  btn-sm" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                &nbsp;
                                <a href="<?php echo e(url('supplier/' . $subcat->id)); ?>" class="btn btn-info  btn-sm"
                                    title="View">
                                    <i class="fas fa-eye"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
      
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\awc\awc-pos-main\resources\views/supplier/index.blade.php ENDPATH**/ ?>