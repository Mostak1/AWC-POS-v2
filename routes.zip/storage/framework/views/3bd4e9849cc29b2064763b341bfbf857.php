<?php $__env->startSection('title'); ?>
Role Page - Admin Panel
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- Start datatable css -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.bootstrap5.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- page title area start -->
    <div class="page-title-area">
        <div class="row align-items-center">
            <div class="col-sm-6">
                <div class="breadcrumbs-area clearfix">
                    <h4 class="page-title pull-start">Roles</h4>
                    <ul class="breadcrumbs pull-start">
                        <li><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                        <li><span>All Roles</span></li>
                    </ul>
                </div>
            </div>
          
        </div>
    </div>
    <!-- page title area end -->

    <div class="main-content-inner">
        <div class="row">
            <!-- data table start -->
            <div class="col-12 mt-5">
                <div class="card">
                    <div class="card-body">
                        <h4 class="header-title float-start">Roles List</h4>
                        <p class="float-end mb-2">
                            <?php if(Auth::guard('web')->user()->can('roles.create')): ?>
                                <a class="btn btn-primary text-white" href="<?php echo e(route('roles.create')); ?>">Create New Role</a>
                            <?php endif; ?>
                        </p>
                        <div class="clearfix"></div>
                        <div class="data-tables">
                            
                            <table id="dataTable3" class="table">
                                <thead class="bg-light text-capitalize">
                                    <tr>
                                        <th width="5%">Sl</th>
                                        <th width="10%">Name</th>
                                        <th width="60%">Permissions</th>
                                        <th width="15%">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->index+1); ?></td>
                                            <td><?php echo e($role->name); ?></td>
                                            <td>
                                                <?php $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span class="badge text-bg-info">
                                                        <?php echo e($perm->name); ?>

                                                    </span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                            <td>
                                                <div class="skip d-flex justify-content-center">

                                                    <?php if(Auth::guard('web')->user()->can('roles.edit')): ?>
                                                        <a class="btn btn-success" href="<?php echo e(route('roles.edit', $role->id)); ?>">Edit</a>
                                                    <?php endif; ?>
    
                                                    <?php if(Auth::guard('web')->user()->can('roles.destroy')): ?>
                                                        <a class="btn btn-danger " href="<?php echo e(route('roles.destroy', $role->id)); ?>"
                                                            onclick="event.preventDefault(); document.getElementById('delete-form-<?php echo e($role->id); ?>').submit();">
                                                            Delete
                                                        </a>
    
                                                        <form id="delete-form-<?php echo e($role->id); ?>" action="<?php echo e(route('roles.destroy', $role->id)); ?>" method="POST" style="display: none;">
                                                            <?php echo method_field('DELETE'); ?>
                                                            <?php echo csrf_field(); ?>
                                                        </form>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- data table end -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- Start datatable js -->
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.9/js/responsive.bootstrap5.min.js"></script>

    <script>
        /*================================
        datatable active
        ==================================*/
        if ($('#dataTable3').length) {
            $('#dataTable3').DataTable({
                responsive: true
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\awc\awc-pos-main\resources\views/roles/index.blade.php ENDPATH**/ ?>