<?php $__env->startSection('content'); ?>
    <div class="card card-hover shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between">
            <h4 class="m-0 font-weight-bold text-info">Update Order <?php echo e($offorder->id); ?></h4>
            <a href="<?php echo e(url('offorder')); ?>" class="btn btn-info  btn-sm" title="Back to Class">
                <i class="fas fa-arrow-left"></i>
            </a>
        </div>
        <div class="card-body">
            <?php echo Form::model($offorder, [
                'method' => 'put',
                'enctype' => 'multipart/form-data',
                'class' => 'Order',
                'route' => ['offorder.update', $offorder->id],
            ]); ?>

            <div class="form-group row">
                <div class="col-sm-4">
                    <label for="tab_id" class="form-label">Table Name:</label>
                    <?php echo Form::select('tab_id', $tabs, null, [
                        'required',
                        'class' => 'form-control form-control-profile',
                        'id' => 'tab_id',
                    ]); ?>

                </div>
                <div class="col-sm-4 mb-3 mb-sm-0">
                    <label for="total" class="form-label">Total :</label>
                    <?php echo Form::number('total', null, ['required', 'class' => 'form-control form-control-profile', 'id' => 'total']); ?>

                </div>
                <div class="col-sm-4 mb-3 mb-sm-0">
                    <label for="discount" class="form-label">Discount :</label>
                    <?php echo Form::number('discount', null, [
                        'required',
                        'class' => 'form-control form-control-profile',
                        'id' => 'discount',
                    ]); ?>

                </div>
                <div class="col-sm-4 mb-3 mb-sm-0">
                    <label for="reason" class="form-label">Reason :</label>
                    <?php echo Form::text('reason', null, ['required', 'class' => 'form-control form-control-profile', 'id' => 'reason']); ?>

                </div>
                <div class="col-sm-4 mb-3 mb-sm-0">
                    <label for="active" class="form-label">Active :</label>
                    <?php echo Form::select('active', [
                        '1' =>'Customer',
                        '2'=>'Staff',
                        '3'=>'Pathao', 
                        '4'=>'Food Panda',
                        '5'=>'Chairman Sir',
                        '6'=>'IPD',
                    ], null,['required', 'class' => 'form-control form-control-profile', 'id' => 'active']); ?>

                </div>

                
            </div>
            <div class="form-group">
                <?php echo Form::submit('Update Orders', ['class' => 'mt-3 btn btn-info btn-profile btn-block']); ?>

            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\awc\awc-pos-main\resources\views/offorder/edit.blade.php ENDPATH**/ ?>