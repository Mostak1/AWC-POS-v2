
<?php $__env->startSection('content'); ?>
    <div class="card card-hover shadow mb-4">
        <!-- Card Header - Dropdown -->
        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
            <h4 class="m-0 font-weight-bold text-info">List of Classes</h4>
            <div class="fs-4 text-danger">
                <span class="me-4">Total Order Item: <?php echo e($orderCountD); ?></span>
                <span class="me-4">Total Sale: <?php echo e($totalSalesD); ?> TK</span>
                <span class="me-4">Total Discount: <?php echo e($totalDisD); ?> TK</span>
                <span class="me-4">Net Sale: <?php echo e($totalSalesD - $totalDisD); ?> TK</span>
            </div>

        </div>
        <!-- Card Body -->
        <div class="card-body mt-4">
            <div class="table-responsive">
                <table class="table table-bordered dataTable" id="" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th colspan="8" class="tablebtn text-end">
                            </th>
                        </tr>
                        <tr>
                            <th>#</th>
                            <th>Ordered By</th>
                            <th>Order Time</th>
                            <th>Food Name</th>
                            <th>Total Amount</th>
                            <th>Discount</th>
                            <th>Reason</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offorder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($offorder->id); ?></td>
                                <td><?php echo e($offorder->user->name); ?></td>
                                <td><?php echo e($offorder->created_at->format('dM-y H:i A')); ?></td>
                                <td>
                                    <?php $__currentLoopData = $offorder->offorderdetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="">
                                            <span class="fs-6 "><?php echo e($detail->menu->name); ?> -</span>
                                            <span class="fs-6">Qty: <?php echo e($detail->quantity); ?> </span>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td><?php echo e($offorder->total); ?></td>
                                <td><?php echo e($offorder->discount); ?></td>
                                <td><?php echo e($offorder->reason); ?></td>

                                <td class="skip d-flex justify-content-center">
                                    <?php echo Form::open(['method' => 'delete', 'route' => ['offorder.destroy', $offorder->id], 'id' => 'deleteform']); ?>

                                    <a href="javascript:void(0)" class="btn btn-danger  btn-sm" title="Delete"
                                        onclick="event.preventDefault();if (!confirm('Are you sure?')) return; document.getElementById('deleteform').submit();">
                                        <i class="fa-solid fa-trash-can"></i>
                                    </a>
                                    <?php echo Form::close(); ?>

                                    &nbsp;
                                    <a href="<?php echo e(url('offorder/' . $offorder->id . '/edit')); ?>" class="btn btn-info  btn-sm"
                                        title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    &nbsp;
                                    <a href="<?php echo e(url('offorder/' . $offorder->id)); ?>" class="btn btn-info  btn-sm"
                                        title="View">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\awc\awc-pos-main\resources\views/report/weeklyreport.blade.php ENDPATH**/ ?>