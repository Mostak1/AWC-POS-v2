
<?php $__env->startSection('css'); ?>
    <style>
        @media print {

            table,
            .ptext {
                font-size: 10pt;
                margin-bottom: 1px;
            }

            th,
            td {
                padding: 0px;
                height: 4px;

            }



            @page {
                margin: 0.2in;
            }
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">


        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
            <h4 class="m-0 font-weight-bold text-info">Order Report Table</h4>
            <div class="m-0 font-weight-bold btn btn-outline-info" id="submitp"><i class="fa-solid fa-print"></i></div>
        </div>
        <div class="card p-4 d-print-block">

            <div class="row fs-6" id="printTable">
                <div class="col-12">
                    <div class="table-responsive">
                        <div class="text-center fs-5">Green-Kitchen Daily Report</div>

                        <div class="text-center fs-5">Staff </div>

                        <table class="table table-bordered" id="stafforderdetails" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Menu Name</th>
                                    <th>Category</th>
                                    <th>Quantity</th>
                                    <th>Price</th>
                                    <th>Total</th>
                                    <!-- Add more table headers based on your new filters -->
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th class="text-start">Total Sale <?php echo e($staffSale); ?> tk</th>
                                    <th class="text-end" colspan="2">Total Discount <?php echo e($staffDis); ?> tk</th>
                                    <th class="text-end" colspan="2">Net Sale <?php echo e($staffSale - $staffDis); ?> tk</th>
                                </tr>
                            </tfoot>
                            <tbody>
                                <?php $__currentLoopData = $staffData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item['menuName']); ?></td>
                                        <td><?php echo e($item['category']); ?></td>
                                        <td><?php echo e($item['quantity']); ?></td>
                                        <td><?php echo e($item['price']); ?></td>
                                        <td><?php echo e($item['total']); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div id="stafftotal">
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="table-responsive" id="">
                        <div class="text-center fs-5">Customer</div>
                        <div class="text-center fs-3" id="filterHead"></div>
                        <table class="table table-bordered" id="customerdata" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Menu Name</th>
                                    <th>Category</th>
                                    <th>Quantity</th>
                                    <th>Price</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th class="text-start">Total Sale <?php echo e($customerSale); ?> tk</th>
                                    <th class="text-end" colspan="2">Total Discount <?php echo e($customerDis); ?> tk</th>
                                    <th class="text-end" colspan="2">Net Sale <?php echo e($customerSale - $customerDis); ?> tk</th>
                                </tr>
                            </tfoot>
                            <tbody>
                                <?php $__currentLoopData = $customerData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item['menuName']); ?></td>
                                        <td><?php echo e($item['category']); ?></td>
                                        <td><?php echo e($item['quantity']); ?></td>
                                        <td><?php echo e($item['price']); ?></td>
                                        <td><?php echo e($item['total']); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div id="customertotal">

                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="table-responsive" id="">
                        <div class="text-center fs-5">Pathao</div>
                        <div class="text-center fs-3" id="filterHead"></div>
                        <table class="table table-bordered" id="customerdata" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Menu Name</th>
                                    <th>Category</th>
                                    <th>Quantity</th>
                                    <th>Price</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th class="text-start">Total Sale <?php echo e($pathaoSale); ?> tk</th>
                                    <th class="text-end" colspan="2">Total Discount <?php echo e($pathaoDis); ?> tk</th>
                                    <th class="text-end" colspan="2">Net Sale <?php echo e($pathaoSale - $pathaoDis); ?> tk</th>
                                </tr>
                            </tfoot>
                            <tbody>
                                <?php $__currentLoopData = $pathao; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item['menuName']); ?></td>
                                        <td><?php echo e($item['category']); ?></td>
                                        <td><?php echo e($item['quantity']); ?></td>
                                        <td><?php echo e($item['price']); ?></td>
                                        <td><?php echo e($item['total']); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div id="customertotal">

                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="table-responsive" id="">
                        <div class="text-center fs-5">Food Panda</div>
                        <div class="text-center fs-3" id="filterHead"></div>
                        <table class="table table-bordered" id="customerdata" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Menu Name</th>
                                    <th>Category</th>
                                    <th>Quantity</th>
                                    <th>Price</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th class="text-start">Total Sale <?php echo e($foodPandaSale); ?> tk</th>
                                    <th class="text-end" colspan="2">Total Discount <?php echo e($foodPandaDis); ?> tk</th>
                                    <th class="text-end" colspan="2">Net Sale <?php echo e($foodPandaSale - $foodPandaDis); ?> tk
                                    </th>
                                </tr>
                            </tfoot>
                            <tbody>
                                <?php $__currentLoopData = $foodPanda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item['menuName']); ?></td>
                                        <td><?php echo e($item['category']); ?></td>
                                        <td><?php echo e($item['quantity']); ?></td>
                                        <td><?php echo e($item['price']); ?></td>
                                        <td><?php echo e($item['total']); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div id="customertotal">

                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="table-responsive" id="">
                        <div class="text-center fs-5">IPD</div>
                        <div class="text-center fs-3" id="filterHead"></div>
                        <table class="table table-bordered" id="customerdata" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Menu Name</th>
                                    <th>Category</th>
                                    <th>Quantity</th>
                                    <th>Price</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th class="text-start">Total Sale <?php echo e($ipdSale); ?> tk</th>
                                    <th class="text-end" colspan="2">Total Discount <?php echo e($ipdDis); ?> tk</th>
                                    <th class="text-end" colspan="2">Net Sale <?php echo e($ipdSale - $ipdDis); ?> tk</th>
                                </tr>
                            </tfoot>
                            <tbody>
                                <?php $__currentLoopData = $ipd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item['menuName']); ?></td>
                                        <td><?php echo e($item['category']); ?></td>
                                        <td><?php echo e($item['quantity']); ?></td>
                                        <td><?php echo e($item['price']); ?></td>
                                        <td><?php echo e($item['total']); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div id="customertotal">

                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="table-responsive" id="">
                        <div class="text-center fs-5">Chairman Sir</div>
                        <div class="text-center fs-3" id="filterHead"></div>
                        <table class="table table-bordered" id="customerdata" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Menu Name</th>
                                    <th>Category</th>
                                    <th>Quantity</th>
                                    <th>Price</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th class="text-start">Total Sale <?php echo e($chairmanSale); ?> tk</th>
                                    <th class="text-end" colspan="2">Total Discount <?php echo e($chairmanDis); ?> tk</th>
                                    <th class="text-end" colspan="2">Net Sale <?php echo e($chairmanSale - $chairmanDis); ?> tk
                                    </th>
                                </tr>
                            </tfoot>
                            <tbody>
                                <?php $__currentLoopData = $chairman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item['menuName']); ?></td>
                                        <td><?php echo e($item['category']); ?></td>
                                        <td><?php echo e($item['quantity']); ?></td>
                                        <td><?php echo e($item['price']); ?></td>
                                        <td><?php echo e($item['total']); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div id="customertotal">

                        </div>
                    </div>
                </div>
                <div class="pt-2 ptext d-flex flex-row align-items-center justify-content-between">
                    <div class="m-0 font-weight-bold ">
                        <span class="me-2">
                            Date: <?php echo e($selectedDate); ?>

                        </span>
                        <span class="me-2">
                            Total Order: <?php echo e($orderCountD); ?>

                        </span>
                    </div>
                    <div>
                        Total Sale: <?php echo e($totalSalesD); ?>TK ;
                    </div>
                    <div>
                        Total Discount: <?php echo e($totalDisD); ?>TK ;
                    </div>
                    <div>
                        Net Sale: <?php echo e($totalSalesD-$totalDisD); ?>TK ;
                    </div>
                    

                </div>
                <div class="py-2 ptext d-flex flex-row align-items-center justify-content-between">
                        <div class=" bold">Cash on Hand: <?php echo e($totalSalesD+$pathaoDis+$foodPandaDis-$totalDisD-$foodPandaSale-$pathaoSale-$ipdSale-$bkash-$card); ?>TK;</div>
                        <div class="">Bkash:<?php echo e($bkash); ?>TK;</div>
                        <div class=""> Card: <?php echo e($card); ?>TK</div>
                </div>
            </div>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        // Printn
        $('#submitp').click(function() {
            var printContents = $('#printTable').html();

            var originalContents = document.body.innerHTML;
            document.body.innerHTML = printContents;
            window.print();
            document.body.innerHTML = originalContents;


            // $("#orders").empty();
            location.reload();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\awc\awc-pos-main\resources\views/report/dailyreport.blade.php ENDPATH**/ ?>