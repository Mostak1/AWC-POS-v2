<?php $__env->startSection('content'); ?>
    <div class="card card-hover shadow mb-4">
        <!-- Card Header - Dropdown -->
        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
            <h4 class="m-0 font-weight-bold text-info">List of Orders Log</h4>
            <div class="">
                
            </div>
        </div>
        <!-- Card Body -->
        <div class="card-body mt-4">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th colspan="7" class="tablebtn text-end">
                            </th>
                        </tr>
                        <tr>
                            <th>Log ID</th>
                            <th>Order Id</th>
                            <th>User Name</th>
                            <th>Old Value</th>
                            <th>New Value</th>
                            <th>Process Sector</th>
                            <th>Process Time</th>
                           
                        </tr>
                    </thead>
                    
                    <tbody>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->id); ?></td>
                                <td><?php echo e($item->menu_id); ?></td>
                                <td><?php echo e($item->user->name); ?></td>
                                <td><?php echo e($item->old); ?></td>
                                <td><?php echo e($item->new); ?></td>
                                <td><?php echo e($item->methode); ?></td>
                                <td><?php echo e($item->created_at); ?></td>
                                
                               
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\awc\awc-pos-main\resources\views/menu/log.blade.php ENDPATH**/ ?>