<?php $__env->startSection('content'); ?>
    <div class="card card-hover shadow mt-0 mb-4">
        <div class="card-header py-3 d-flex justify-content-between">
            <h4 class="m-0 font-weight-bold text-info">Update discount Info</h4>
            <a href="<?php echo e(url('discounts')); ?>" class="btn btn-info  btn-sm" title="Back to discounts">
                <i class="fas fa-arrow-left"></i>
            </a>
        </div>
        <div class="card-body">

            <?php echo Form::model($discount, [
                'method' => 'put',
                'enctype' => 'multipart/form-data',
                'class' => 'user',
                'route' => ['discounts.update', ['discount' => $discount->id]],
            ]); ?>


            <div class="form-group row g-4">
                
                <div class="col-sm-4 mb-3 mb-sm-0">
                    <label for="name" class="form-label">Policy Name :</label>
                    <?php echo Form::text('name', null, [
                        'required',
                        'class' => 'form-control form-control-profile',
                        'id' => 'name',
                        'placeholder' => 'Name',
                    ]); ?>

                </div>
               
                <div class="col-sm-4 mb-3 mb-sm-0">
                    <label for="discount" class="form-label">Discount In Percentage:</label>
                    <?php echo Form::number('discount', null, [
                        'required',
                        'class' => 'form-control form-control-profile',
                        'id' => 'discount',
                        'placeholder' => '20/10/5',
                    ]); ?>

                </div>
                <div class="col-sm-4 mb-3 mb-sm-0">
                    <label for="fixed" class="form-label">Discount In Fixed:</label>
                    <?php echo Form::number('fixed', null, [
                        'required',
                        'class' => 'form-control form-control-profile',
                        'id' => 'fixed',
                        'placeholder' => '50/100/200',
                    ]); ?>

                </div>
                
            </div>

        </div>
        <div class="form-group m-3">
            <?php echo Form::submit('Update discounts Info', ['class' => 'mt-3 btn btn-info btn-profile btn-block']); ?>

        </div>
        <?php echo Form::close(); ?>

    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\awc\awc-pos-main\resources\views/discount/edit.blade.php ENDPATH**/ ?>