<?php


return [
    'c_name' => 'Unknown',
    'logo' => env('LOGO', 'default_logo.png'),
    'address' => env('ADDRESS', 'Default Address'),
    'mobile' => env('MOBILE', 'Default Mobile'),
    'phone' => env('PHONE', 'Default Phone'),
    'website' => env('WEBSITE', 'https://example.com'),
    'tax' => env('TAX', 0),
    'discount' => env('DISCOUNT', 0),
];
